
--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `accesslog`
--
ALTER TABLE `accesslog`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `accesslog_timestamp` (`timestamp`),
  ADD KEY `uid` (`uid`);

--
-- Индексы таблицы `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`aid`);

--
-- Индексы таблицы `authmap`
--
ALTER TABLE `authmap`
  ADD PRIMARY KEY (`aid`),
  ADD UNIQUE KEY `authname` (`authname`);

--
-- Индексы таблицы `backup_migrate_destinations`
--
ALTER TABLE `backup_migrate_destinations`
  ADD PRIMARY KEY (`destination_id`);

--
-- Индексы таблицы `backup_migrate_profiles`
--
ALTER TABLE `backup_migrate_profiles`
  ADD PRIMARY KEY (`profile_id`);

--
-- Индексы таблицы `backup_migrate_schedules`
--
ALTER TABLE `backup_migrate_schedules`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Индексы таблицы `backup_migrate_sources`
--
ALTER TABLE `backup_migrate_sources`
  ADD PRIMARY KEY (`source_id`);

--
-- Индексы таблицы `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `token` (`token`);

--
-- Индексы таблицы `block`
--
ALTER TABLE `block`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `tmd` (`theme`,`module`,`delta`),
  ADD KEY `list` (`theme`,`status`,`region`,`weight`,`module`);

--
-- Индексы таблицы `blocked_ips`
--
ALTER TABLE `blocked_ips`
  ADD PRIMARY KEY (`iid`),
  ADD KEY `blocked_ip` (`ip`);

--
-- Индексы таблицы `block_custom`
--
ALTER TABLE `block_custom`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `info` (`info`);

--
-- Индексы таблицы `block_node_type`
--
ALTER TABLE `block_node_type`
  ADD PRIMARY KEY (`module`,`delta`,`type`),
  ADD KEY `type` (`type`);

--
-- Индексы таблицы `block_role`
--
ALTER TABLE `block_role`
  ADD PRIMARY KEY (`module`,`delta`,`rid`),
  ADD KEY `rid` (`rid`);

--
-- Индексы таблицы `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_admin_menu`
--
ALTER TABLE `cache_admin_menu`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_block`
--
ALTER TABLE `cache_block`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_bootstrap`
--
ALTER TABLE `cache_bootstrap`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_field`
--
ALTER TABLE `cache_field`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_filter`
--
ALTER TABLE `cache_filter`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_form`
--
ALTER TABLE `cache_form`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_image`
--
ALTER TABLE `cache_image`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_libraries`
--
ALTER TABLE `cache_libraries`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_menu`
--
ALTER TABLE `cache_menu`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_metatag`
--
ALTER TABLE `cache_metatag`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_page`
--
ALTER TABLE `cache_page`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_panels`
--
ALTER TABLE `cache_panels`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_path`
--
ALTER TABLE `cache_path`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_token`
--
ALTER TABLE `cache_token`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_update`
--
ALTER TABLE `cache_update`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_views`
--
ALTER TABLE `cache_views`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `cache_views_data`
--
ALTER TABLE `cache_views_data`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `captcha_points`
--
ALTER TABLE `captcha_points`
  ADD PRIMARY KEY (`form_id`);

--
-- Индексы таблицы `captcha_sessions`
--
ALTER TABLE `captcha_sessions`
  ADD PRIMARY KEY (`csid`),
  ADD KEY `csid_ip` (`csid`,`ip_address`);

--
-- Индексы таблицы `ckeditor_input_format`
--
ALTER TABLE `ckeditor_input_format`
  ADD PRIMARY KEY (`name`,`format`);

--
-- Индексы таблицы `ckeditor_settings`
--
ALTER TABLE `ckeditor_settings`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `comment_status_pid` (`pid`,`status`),
  ADD KEY `comment_num_new` (`nid`,`status`,`created`,`cid`,`thread`),
  ADD KEY `comment_uid` (`uid`),
  ADD KEY `comment_nid_language` (`nid`,`language`),
  ADD KEY `comment_created` (`created`);

--
-- Индексы таблицы `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `category` (`category`),
  ADD KEY `list` (`weight`,`category`);

--
-- Индексы таблицы `ctools_access_ruleset`
--
ALTER TABLE `ctools_access_ruleset`
  ADD PRIMARY KEY (`rsid`);

--
-- Индексы таблицы `ctools_css_cache`
--
ALTER TABLE `ctools_css_cache`
  ADD PRIMARY KEY (`cid`);

--
-- Индексы таблицы `ctools_custom_content`
--
ALTER TABLE `ctools_custom_content`
  ADD PRIMARY KEY (`cid`);

--
-- Индексы таблицы `ctools_object_cache`
--
ALTER TABLE `ctools_object_cache`
  ADD PRIMARY KEY (`sid`,`obj`,`name`),
  ADD KEY `updated` (`updated`);

--
-- Индексы таблицы `date_formats`
--
ALTER TABLE `date_formats`
  ADD PRIMARY KEY (`dfid`),
  ADD UNIQUE KEY `formats` (`format`,`type`);

--
-- Индексы таблицы `date_format_locale`
--
ALTER TABLE `date_format_locale`
  ADD PRIMARY KEY (`type`,`language`);

--
-- Индексы таблицы `date_format_type`
--
ALTER TABLE `date_format_type`
  ADD PRIMARY KEY (`type`),
  ADD KEY `title` (`title`);

--
-- Индексы таблицы `field_config`
--
ALTER TABLE `field_config`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_name` (`field_name`),
  ADD KEY `active` (`active`),
  ADD KEY `storage_active` (`storage_active`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `module` (`module`),
  ADD KEY `storage_module` (`storage_module`),
  ADD KEY `type` (`type`),
  ADD KEY `storage_type` (`storage_type`);

--
-- Индексы таблицы `field_config_instance`
--
ALTER TABLE `field_config_instance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_name_bundle` (`field_name`,`entity_type`,`bundle`),
  ADD KEY `deleted` (`deleted`);

--
-- Индексы таблицы `field_data_body`
--
ALTER TABLE `field_data_body`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `body_format` (`body_format`);

--
-- Индексы таблицы `field_data_comment_body`
--
ALTER TABLE `field_data_comment_body`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `comment_body_format` (`comment_body_format`);

--
-- Индексы таблицы `field_data_field_category_servise`
--
ALTER TABLE `field_data_field_category_servise`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_category_servise_tid` (`field_category_servise_tid`);

--
-- Индексы таблицы `field_data_field_category_vermin`
--
ALTER TABLE `field_data_field_category_vermin`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_category_vermin_tid` (`field_category_vermin_tid`);

--
-- Индексы таблицы `field_data_field_image`
--
ALTER TABLE `field_data_field_image`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_image_fid` (`field_image_fid`);

--
-- Индексы таблицы `field_data_field_photo`
--
ALTER TABLE `field_data_field_photo`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_photo_fid` (`field_photo_fid`);

--
-- Индексы таблицы `field_data_field_pic_handbook`
--
ALTER TABLE `field_data_field_pic_handbook`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_pic_handbook_fid` (`field_pic_handbook_fid`);

--
-- Индексы таблицы `field_data_field_simplenews_term`
--
ALTER TABLE `field_data_field_simplenews_term`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_simplenews_term_tid` (`field_simplenews_term_tid`);

--
-- Индексы таблицы `field_data_field_tags`
--
ALTER TABLE `field_data_field_tags`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_tags_tid` (`field_tags_tid`);

--
-- Индексы таблицы `field_data_taxonomy_forums`
--
ALTER TABLE `field_data_taxonomy_forums`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `taxonomy_forums_tid` (`taxonomy_forums_tid`);

--
-- Индексы таблицы `field_revision_body`
--
ALTER TABLE `field_revision_body`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `body_format` (`body_format`);

--
-- Индексы таблицы `field_revision_comment_body`
--
ALTER TABLE `field_revision_comment_body`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `comment_body_format` (`comment_body_format`);

--
-- Индексы таблицы `field_revision_field_category_servise`
--
ALTER TABLE `field_revision_field_category_servise`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_category_servise_tid` (`field_category_servise_tid`);

--
-- Индексы таблицы `field_revision_field_category_vermin`
--
ALTER TABLE `field_revision_field_category_vermin`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_category_vermin_tid` (`field_category_vermin_tid`);

--
-- Индексы таблицы `field_revision_field_image`
--
ALTER TABLE `field_revision_field_image`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_image_fid` (`field_image_fid`);

--
-- Индексы таблицы `field_revision_field_photo`
--
ALTER TABLE `field_revision_field_photo`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_photo_fid` (`field_photo_fid`);

--
-- Индексы таблицы `field_revision_field_pic_handbook`
--
ALTER TABLE `field_revision_field_pic_handbook`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_pic_handbook_fid` (`field_pic_handbook_fid`);

--
-- Индексы таблицы `field_revision_field_simplenews_term`
--
ALTER TABLE `field_revision_field_simplenews_term`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_simplenews_term_tid` (`field_simplenews_term_tid`);

--
-- Индексы таблицы `field_revision_field_tags`
--
ALTER TABLE `field_revision_field_tags`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `field_tags_tid` (`field_tags_tid`);

--
-- Индексы таблицы `field_revision_taxonomy_forums`
--
ALTER TABLE `field_revision_taxonomy_forums`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  ADD KEY `entity_type` (`entity_type`),
  ADD KEY `bundle` (`bundle`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `entity_id` (`entity_id`),
  ADD KEY `revision_id` (`revision_id`),
  ADD KEY `language` (`language`),
  ADD KEY `taxonomy_forums_tid` (`taxonomy_forums_tid`);

--
-- Индексы таблицы `file_managed`
--
ALTER TABLE `file_managed`
  ADD PRIMARY KEY (`fid`),
  ADD UNIQUE KEY `uri` (`uri`),
  ADD KEY `uid` (`uid`),
  ADD KEY `status` (`status`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Индексы таблицы `file_usage`
--
ALTER TABLE `file_usage`
  ADD PRIMARY KEY (`fid`,`type`,`id`,`module`),
  ADD KEY `type_id` (`type`,`id`),
  ADD KEY `fid_count` (`fid`,`count`),
  ADD KEY `fid_module` (`fid`,`module`);

--
-- Индексы таблицы `filter`
--
ALTER TABLE `filter`
  ADD PRIMARY KEY (`format`,`name`),
  ADD KEY `list` (`weight`,`module`,`name`);

--
-- Индексы таблицы `filter_format`
--
ALTER TABLE `filter_format`
  ADD PRIMARY KEY (`format`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `status_weight` (`status`,`weight`);

--
-- Индексы таблицы `flood`
--
ALTER TABLE `flood`
  ADD PRIMARY KEY (`fid`),
  ADD KEY `allow` (`event`,`identifier`,`timestamp`),
  ADD KEY `purge` (`expiration`);

--
-- Индексы таблицы `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`vid`),
  ADD KEY `forum_topic` (`nid`,`tid`),
  ADD KEY `tid` (`tid`);

--
-- Индексы таблицы `forum_index`
--
ALTER TABLE `forum_index`
  ADD KEY `forum_topics` (`nid`,`tid`,`sticky`,`last_comment_timestamp`),
  ADD KEY `created` (`created`),
  ADD KEY `last_comment_timestamp` (`last_comment_timestamp`);

--
-- Индексы таблицы `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`uid`,`nid`),
  ADD KEY `nid` (`nid`);

--
-- Индексы таблицы `image_effects`
--
ALTER TABLE `image_effects`
  ADD PRIMARY KEY (`ieid`),
  ADD KEY `isid` (`isid`),
  ADD KEY `weight` (`weight`);

--
-- Индексы таблицы `image_styles`
--
ALTER TABLE `image_styles`
  ADD PRIMARY KEY (`isid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `l10n_update_file`
--
ALTER TABLE `l10n_update_file`
  ADD PRIMARY KEY (`project`,`language`);

--
-- Индексы таблицы `l10n_update_project`
--
ALTER TABLE `l10n_update_project`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`language`),
  ADD KEY `list` (`weight`,`name`);

--
-- Индексы таблицы `locales_source`
--
ALTER TABLE `locales_source`
  ADD PRIMARY KEY (`lid`),
  ADD KEY `source_context` (`source`(30),`context`);

--
-- Индексы таблицы `locales_target`
--
ALTER TABLE `locales_target`
  ADD PRIMARY KEY (`language`,`lid`,`plural`),
  ADD KEY `lid` (`lid`),
  ADD KEY `plid` (`plid`),
  ADD KEY `plural` (`plural`);

--
-- Индексы таблицы `menu_custom`
--
ALTER TABLE `menu_custom`
  ADD PRIMARY KEY (`menu_name`);

--
-- Индексы таблицы `menu_links`
--
ALTER TABLE `menu_links`
  ADD PRIMARY KEY (`mlid`),
  ADD KEY `path_menu` (`link_path`(128),`menu_name`),
  ADD KEY `menu_plid_expand_child` (`menu_name`,`plid`,`expanded`,`has_children`),
  ADD KEY `menu_parents` (`menu_name`,`p1`,`p2`,`p3`,`p4`,`p5`,`p6`,`p7`,`p8`,`p9`),
  ADD KEY `router_path` (`router_path`(128));

--
-- Индексы таблицы `menu_router`
--
ALTER TABLE `menu_router`
  ADD PRIMARY KEY (`path`),
  ADD KEY `fit` (`fit`),
  ADD KEY `tab_parent` (`tab_parent`(64),`weight`,`title`),
  ADD KEY `tab_root_weight_title` (`tab_root`(64),`weight`,`title`);

--
-- Индексы таблицы `metatag`
--
ALTER TABLE `metatag`
  ADD PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`language`),
  ADD KEY `type_revision` (`entity_type`,`revision_id`);

--
-- Индексы таблицы `metatag_config`
--
ALTER TABLE `metatag_config`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `instance` (`instance`);

--
-- Индексы таблицы `node`
--
ALTER TABLE `node`
  ADD PRIMARY KEY (`nid`),
  ADD UNIQUE KEY `vid` (`vid`),
  ADD KEY `node_changed` (`changed`),
  ADD KEY `node_created` (`created`),
  ADD KEY `node_frontpage` (`promote`,`status`,`sticky`,`created`),
  ADD KEY `node_status_type` (`status`,`type`,`nid`),
  ADD KEY `node_title_type` (`title`,`type`(4)),
  ADD KEY `node_type` (`type`(4)),
  ADD KEY `uid` (`uid`),
  ADD KEY `tnid` (`tnid`),
  ADD KEY `translate` (`translate`),
  ADD KEY `language` (`language`);

--
-- Индексы таблицы `node_access`
--
ALTER TABLE `node_access`
  ADD PRIMARY KEY (`nid`,`gid`,`realm`);

--
-- Индексы таблицы `node_comment_statistics`
--
ALTER TABLE `node_comment_statistics`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `node_comment_timestamp` (`last_comment_timestamp`),
  ADD KEY `comment_count` (`comment_count`),
  ADD KEY `last_comment_uid` (`last_comment_uid`);

--
-- Индексы таблицы `node_counter`
--
ALTER TABLE `node_counter`
  ADD PRIMARY KEY (`nid`);

--
-- Индексы таблицы `node_revision`
--
ALTER TABLE `node_revision`
  ADD PRIMARY KEY (`vid`),
  ADD KEY `nid` (`nid`),
  ADD KEY `uid` (`uid`);

--
-- Индексы таблицы `node_type`
--
ALTER TABLE `node_type`
  ADD PRIMARY KEY (`type`);

--
-- Индексы таблицы `page_manager_handlers`
--
ALTER TABLE `page_manager_handlers`
  ADD PRIMARY KEY (`did`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `fulltask` (`task`,`subtask`,`weight`);

--
-- Индексы таблицы `page_manager_pages`
--
ALTER TABLE `page_manager_pages`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `task` (`task`);

--
-- Индексы таблицы `page_manager_weights`
--
ALTER TABLE `page_manager_weights`
  ADD PRIMARY KEY (`name`),
  ADD KEY `weights` (`name`,`weight`);

--
-- Индексы таблицы `panels_allowed_types`
--
ALTER TABLE `panels_allowed_types`
  ADD KEY `type_idx` (`type`);

--
-- Индексы таблицы `panels_display`
--
ALTER TABLE `panels_display`
  ADD PRIMARY KEY (`did`);

--
-- Индексы таблицы `panels_layout`
--
ALTER TABLE `panels_layout`
  ADD PRIMARY KEY (`lid`);

--
-- Индексы таблицы `panels_mini`
--
ALTER TABLE `panels_mini`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `panels_node`
--
ALTER TABLE `panels_node`
  ADD PRIMARY KEY (`did`);

--
-- Индексы таблицы `panels_pane`
--
ALTER TABLE `panels_pane`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `did_idx` (`did`);

--
-- Индексы таблицы `panels_renderer_pipeline`
--
ALTER TABLE `panels_renderer_pipeline`
  ADD PRIMARY KEY (`rpid`);

--
-- Индексы таблицы `pathauto_state`
--
ALTER TABLE `pathauto_state`
  ADD PRIMARY KEY (`entity_type`,`entity_id`);

--
-- Индексы таблицы `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `name_created` (`name`,`created`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `rdf_mapping`
--
ALTER TABLE `rdf_mapping`
  ADD PRIMARY KEY (`type`,`bundle`);

--
-- Индексы таблицы `registry`
--
ALTER TABLE `registry`
  ADD PRIMARY KEY (`name`,`type`),
  ADD KEY `hook` (`type`,`weight`,`module`);

--
-- Индексы таблицы `registry_file`
--
ALTER TABLE `registry_file`
  ADD PRIMARY KEY (`filename`);

--
-- Индексы таблицы `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`rid`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `name_weight` (`name`,`weight`);

--
-- Индексы таблицы `role_permission`
--
ALTER TABLE `role_permission`
  ADD PRIMARY KEY (`rid`,`permission`),
  ADD KEY `permission` (`permission`);

--
-- Индексы таблицы `search_dataset`
--
ALTER TABLE `search_dataset`
  ADD PRIMARY KEY (`sid`,`type`);

--
-- Индексы таблицы `search_index`
--
ALTER TABLE `search_index`
  ADD PRIMARY KEY (`word`,`sid`,`type`),
  ADD KEY `sid_type` (`sid`,`type`);

--
-- Индексы таблицы `search_node_links`
--
ALTER TABLE `search_node_links`
  ADD PRIMARY KEY (`sid`,`type`,`nid`),
  ADD KEY `nid` (`nid`);

--
-- Индексы таблицы `search_total`
--
ALTER TABLE `search_total`
  ADD PRIMARY KEY (`word`);

--
-- Индексы таблицы `semaphore`
--
ALTER TABLE `semaphore`
  ADD PRIMARY KEY (`name`),
  ADD KEY `value` (`value`),
  ADD KEY `expire` (`expire`);

--
-- Индексы таблицы `sequences`
--
ALTER TABLE `sequences`
  ADD PRIMARY KEY (`value`);

--
-- Индексы таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`sid`,`ssid`),
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `uid` (`uid`),
  ADD KEY `ssid` (`ssid`);

--
-- Индексы таблицы `shortcut_set`
--
ALTER TABLE `shortcut_set`
  ADD PRIMARY KEY (`set_name`);

--
-- Индексы таблицы `shortcut_set_users`
--
ALTER TABLE `shortcut_set_users`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `set_name` (`set_name`);

--
-- Индексы таблицы `simplenews_category`
--
ALTER TABLE `simplenews_category`
  ADD PRIMARY KEY (`tid`);

--
-- Индексы таблицы `simplenews_mail_spool`
--
ALTER TABLE `simplenews_mail_spool`
  ADD PRIMARY KEY (`msid`),
  ADD KEY `tid` (`tid`),
  ADD KEY `status` (`status`),
  ADD KEY `snid_tid` (`snid`,`tid`);

--
-- Индексы таблицы `simplenews_newsletter`
--
ALTER TABLE `simplenews_newsletter`
  ADD PRIMARY KEY (`nid`);

--
-- Индексы таблицы `simplenews_subscriber`
--
ALTER TABLE `simplenews_subscriber`
  ADD PRIMARY KEY (`snid`),
  ADD KEY `mail` (`mail`),
  ADD KEY `uid` (`uid`);

--
-- Индексы таблицы `simplenews_subscription`
--
ALTER TABLE `simplenews_subscription`
  ADD PRIMARY KEY (`snid`,`tid`);

--
-- Индексы таблицы `simpletest`
--
ALTER TABLE `simpletest`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `reporter` (`test_class`,`message_id`);

--
-- Индексы таблицы `simpletest_test_id`
--
ALTER TABLE `simpletest_test_id`
  ADD PRIMARY KEY (`test_id`);

--
-- Индексы таблицы `stylizer`
--
ALTER TABLE `stylizer`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `system`
--
ALTER TABLE `system`
  ADD PRIMARY KEY (`filename`),
  ADD KEY `system_list` (`status`,`bootstrap`,`type`,`weight`,`name`),
  ADD KEY `type_name` (`type`,`name`);

--
-- Индексы таблицы `taxonomy_index`
--
ALTER TABLE `taxonomy_index`
  ADD KEY `term_node` (`tid`,`sticky`,`created`),
  ADD KEY `nid` (`nid`);

--
-- Индексы таблицы `taxonomy_term_data`
--
ALTER TABLE `taxonomy_term_data`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `taxonomy_tree` (`vid`,`weight`,`name`),
  ADD KEY `vid_name` (`vid`,`name`),
  ADD KEY `name` (`name`);

--
-- Индексы таблицы `taxonomy_term_hierarchy`
--
ALTER TABLE `taxonomy_term_hierarchy`
  ADD PRIMARY KEY (`tid`,`parent`),
  ADD KEY `parent` (`parent`);

--
-- Индексы таблицы `taxonomy_vocabulary`
--
ALTER TABLE `taxonomy_vocabulary`
  ADD PRIMARY KEY (`vid`),
  ADD UNIQUE KEY `machine_name` (`machine_name`),
  ADD KEY `list` (`weight`,`name`);

--
-- Индексы таблицы `tracker_node`
--
ALTER TABLE `tracker_node`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `tracker` (`published`,`changed`);

--
-- Индексы таблицы `tracker_user`
--
ALTER TABLE `tracker_user`
  ADD PRIMARY KEY (`nid`,`uid`),
  ADD KEY `tracker` (`uid`,`published`,`changed`);

--
-- Индексы таблицы `url_alias`
--
ALTER TABLE `url_alias`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `alias_language_pid` (`alias`,`language`,`pid`),
  ADD KEY `source_language_pid` (`source`,`language`,`pid`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `access` (`access`),
  ADD KEY `created` (`created`),
  ADD KEY `mail` (`mail`),
  ADD KEY `picture` (`picture`);

--
-- Индексы таблицы `users_roles`
--
ALTER TABLE `users_roles`
  ADD PRIMARY KEY (`uid`,`rid`),
  ADD KEY `rid` (`rid`);

--
-- Индексы таблицы `variable`
--
ALTER TABLE `variable`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `views_display`
--
ALTER TABLE `views_display`
  ADD PRIMARY KEY (`vid`,`id`),
  ADD KEY `vid` (`vid`,`position`);

--
-- Индексы таблицы `views_view`
--
ALTER TABLE `views_view`
  ADD PRIMARY KEY (`vid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `watchdog`
--
ALTER TABLE `watchdog`
  ADD PRIMARY KEY (`wid`),
  ADD KEY `type` (`type`),
  ADD KEY `uid` (`uid`),
  ADD KEY `severity` (`severity`);

--
-- Индексы таблицы `xmlsitemap`
--
ALTER TABLE `xmlsitemap`
  ADD PRIMARY KEY (`id`,`type`),
  ADD KEY `loc` (`loc`),
  ADD KEY `access_status_loc` (`access`,`status`,`loc`),
  ADD KEY `type_subtype` (`type`,`subtype`),
  ADD KEY `language` (`language`);

--
-- Индексы таблицы `xmlsitemap_sitemap`
--
ALTER TABLE `xmlsitemap_sitemap`
  ADD PRIMARY KEY (`smid`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `accesslog`
--
ALTER TABLE `accesslog`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique accesslog ID.';
--
-- AUTO_INCREMENT для таблицы `authmap`
--
ALTER TABLE `authmap`
  MODIFY `aid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique authmap ID.';
--
-- AUTO_INCREMENT для таблицы `backup_migrate_destinations`
--
ALTER TABLE `backup_migrate_destinations`
  MODIFY `destination_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `backup_migrate_profiles`
--
ALTER TABLE `backup_migrate_profiles`
  MODIFY `profile_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `backup_migrate_schedules`
--
ALTER TABLE `backup_migrate_schedules`
  MODIFY `schedule_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `backup_migrate_sources`
--
ALTER TABLE `backup_migrate_sources`
  MODIFY `source_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `block`
--
ALTER TABLE `block`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique block ID.', AUTO_INCREMENT=254;
--
-- AUTO_INCREMENT для таблицы `blocked_ips`
--
ALTER TABLE `blocked_ips`
  MODIFY `iid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: unique ID for IP addresses.';
--
-- AUTO_INCREMENT для таблицы `block_custom`
--
ALTER TABLE `block_custom`
  MODIFY `bid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The block’s block.bid.', AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT для таблицы `captcha_sessions`
--
ALTER TABLE `captcha_sessions`
  MODIFY `csid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'CAPTCHA session ID.', AUTO_INCREMENT=19732;
--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique comment ID.', AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique category ID.', AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `ctools_access_ruleset`
--
ALTER TABLE `ctools_access_ruleset`
  MODIFY `rsid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'A database primary key to ensure uniqueness';
--
-- AUTO_INCREMENT для таблицы `ctools_custom_content`
--
ALTER TABLE `ctools_custom_content`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'A database primary key to ensure uniqueness';
--
-- AUTO_INCREMENT для таблицы `date_formats`
--
ALTER TABLE `date_formats`
  MODIFY `dfid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The date format identifier.', AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT для таблицы `field_config`
--
ALTER TABLE `field_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a field', AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `field_config_instance`
--
ALTER TABLE `field_config_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a field instance', AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT для таблицы `file_managed`
--
ALTER TABLE `file_managed`
  MODIFY `fid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'File ID.', AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT для таблицы `flood`
--
ALTER TABLE `flood`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique flood event ID.', AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `image_effects`
--
ALTER TABLE `image_effects`
  MODIFY `ieid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for an image effect.', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `image_styles`
--
ALTER TABLE `image_styles`
  MODIFY `isid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for an image style.', AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `locales_source`
--
ALTER TABLE `locales_source`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier of this string.', AUTO_INCREMENT=9186;
--
-- AUTO_INCREMENT для таблицы `menu_links`
--
ALTER TABLE `menu_links`
  MODIFY `mlid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The menu link ID (mlid) is the integer primary key.', AUTO_INCREMENT=1055;
--
-- AUTO_INCREMENT для таблицы `metatag_config`
--
ALTER TABLE `metatag_config`
  MODIFY `cid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a metatag configuration set.';
--
-- AUTO_INCREMENT для таблицы `node`
--
ALTER TABLE `node`
  MODIFY `nid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a node.', AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT для таблицы `node_revision`
--
ALTER TABLE `node_revision`
  MODIFY `vid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for this version.', AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT для таблицы `page_manager_handlers`
--
ALTER TABLE `page_manager_handlers`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `page_manager_pages`
--
ALTER TABLE `page_manager_pages`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.';
--
-- AUTO_INCREMENT для таблицы `panels_display`
--
ALTER TABLE `panels_display`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `panels_layout`
--
ALTER TABLE `panels_layout`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'A database primary key to ensure uniqueness.';
--
-- AUTO_INCREMENT для таблицы `panels_mini`
--
ALTER TABLE `panels_mini`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary key for uniqueness.';
--
-- AUTO_INCREMENT для таблицы `panels_pane`
--
ALTER TABLE `panels_pane`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `panels_renderer_pipeline`
--
ALTER TABLE `panels_renderer_pipeline`
  MODIFY `rpid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'A database primary key to ensure uniqueness.';
--
-- AUTO_INCREMENT для таблицы `queue`
--
ALTER TABLE `queue`
  MODIFY `item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique item ID.', AUTO_INCREMENT=741;
--
-- AUTO_INCREMENT для таблицы `role`
--
ALTER TABLE `role`
  MODIFY `rid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique role ID.', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `sequences`
--
ALTER TABLE `sequences`
  MODIFY `value` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The value of the sequence.', AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT для таблицы `simplenews_mail_spool`
--
ALTER TABLE `simplenews_mail_spool`
  MODIFY `msid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a mail spool record.';
--
-- AUTO_INCREMENT для таблицы `simplenews_subscriber`
--
ALTER TABLE `simplenews_subscriber`
  MODIFY `snid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary key: Unique subscriber ID.', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `simpletest`
--
ALTER TABLE `simpletest`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique simpletest message ID.';
--
-- AUTO_INCREMENT для таблицы `simpletest_test_id`
--
ALTER TABLE `simpletest_test_id`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique simpletest ID used to group test results together. Each time a set of tests\n                            are run a new test ID is used.';
--
-- AUTO_INCREMENT для таблицы `stylizer`
--
ALTER TABLE `stylizer`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `taxonomy_term_data`
--
ALTER TABLE `taxonomy_term_data`
  MODIFY `tid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique term ID.', AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT для таблицы `taxonomy_vocabulary`
--
ALTER TABLE `taxonomy_vocabulary`
  MODIFY `vid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique vocabulary ID.', AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `url_alias`
--
ALTER TABLE `url_alias`
  MODIFY `pid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'A unique path alias identifier.', AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT для таблицы `views_view`
--
ALTER TABLE `views_view`
  MODIFY `vid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'The view ID of the field, defined by the database.', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `watchdog`
--
ALTER TABLE `watchdog`
  MODIFY `wid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique watchdog event ID.', AUTO_INCREMENT=22170;