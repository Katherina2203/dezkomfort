
-- --------------------------------------------------------

--
-- Структура таблицы `accesslog`
--

CREATE TABLE `accesslog` (
  `aid` int(11) NOT NULL COMMENT 'Primary Key: Unique accesslog ID.',
  `sid` varchar(128) NOT NULL DEFAULT '' COMMENT 'Browser session ID of user that visited page.',
  `title` varchar(255) DEFAULT NULL COMMENT 'Title of page visited.',
  `path` varchar(255) DEFAULT NULL COMMENT 'Internal path to page visited (relative to Drupal root.)',
  `url` text COMMENT 'Referrer URI.',
  `hostname` varchar(128) DEFAULT NULL COMMENT 'Hostname of user that visited the page.',
  `uid` int(10) UNSIGNED DEFAULT '0' COMMENT 'User users.uid that visited the page.',
  `timer` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Time in milliseconds that the page took to load.',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Timestamp of when the page was visited.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores site access information for statistics.';
