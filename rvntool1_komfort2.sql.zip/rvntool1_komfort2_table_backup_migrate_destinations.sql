
-- --------------------------------------------------------

--
-- Структура таблицы `backup_migrate_destinations`
--

CREATE TABLE `backup_migrate_destinations` (
  `destination_id` int(10) UNSIGNED NOT NULL COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.',
  `machine_name` varchar(255) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a destination.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the destination.',
  `subtype` varchar(32) NOT NULL COMMENT 'The type of the destination.',
  `location` text NOT NULL COMMENT 'The the location string of the destination.',
  `settings` text NOT NULL COMMENT 'Other settings for the destination.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
