
-- --------------------------------------------------------

--
-- Структура таблицы `backup_migrate_profiles`
--

CREATE TABLE `backup_migrate_profiles` (
  `profile_id` int(10) UNSIGNED NOT NULL COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.',
  `machine_name` varchar(255) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `filename` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `append_timestamp` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Append a timestamp to the filename.',
  `timestamp_format` varchar(14) NOT NULL COMMENT 'The format of the timestamp.',
  `filters` text NOT NULL COMMENT 'The filter settings for the profile.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
