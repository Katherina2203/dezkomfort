
-- --------------------------------------------------------

--
-- Структура таблицы `backup_migrate_schedules`
--

CREATE TABLE `backup_migrate_schedules` (
  `schedule_id` int(10) UNSIGNED NOT NULL COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.',
  `machine_name` varchar(255) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `source_id` varchar(255) NOT NULL DEFAULT 'db' COMMENT 'The backup_migrate_destination.destination_id of the source to backup from.',
  `destination_id` varchar(255) NOT NULL DEFAULT '0' COMMENT 'The backup_migrate_destination.destination_id of the destination to back up to.',
  `copy_destination_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'A second backup_migrate_destination.destination_id of the destination to copy the backup to.',
  `profile_id` varchar(255) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `keep` int(11) NOT NULL DEFAULT '0' COMMENT 'The number of backups to keep.',
  `period` int(11) NOT NULL DEFAULT '0' COMMENT 'The number of seconds between backups.',
  `enabled` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Whether the schedule is enabled.',
  `cron` varchar(32) NOT NULL DEFAULT 'builtin' COMMENT 'Whether the schedule should be run during cron.',
  `cron_schedule` varchar(255) NOT NULL DEFAULT '0 4 * * *' COMMENT 'The cron schedule to run on.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
