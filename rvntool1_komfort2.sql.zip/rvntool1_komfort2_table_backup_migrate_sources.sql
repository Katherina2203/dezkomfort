
-- --------------------------------------------------------

--
-- Структура таблицы `backup_migrate_sources`
--

CREATE TABLE `backup_migrate_sources` (
  `source_id` int(10) UNSIGNED NOT NULL COMMENT 'Primary ID field for the table. Not used for anything except internal lookups.',
  `machine_name` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a source.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the source.',
  `subtype` varchar(32) NOT NULL COMMENT 'The type of the source.',
  `location` text NOT NULL COMMENT 'The the location string of the source.',
  `settings` text NOT NULL COMMENT 'Other settings for the source.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
