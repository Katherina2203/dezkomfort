
-- --------------------------------------------------------

--
-- Структура таблицы `block_node_type`
--

CREATE TABLE `block_node_type` (
  `module` varchar(64) NOT NULL COMMENT 'The block’s origin module, from block.module.',
  `delta` varchar(32) NOT NULL COMMENT 'The block’s unique delta within module, from block.delta.',
  `type` varchar(32) NOT NULL COMMENT 'The machine-readable name of this type from node_type.type.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Sets up display criteria for blocks based on content types';

--
-- Дамп данных таблицы `block_node_type`
--

INSERT INTO `block_node_type` (`module`, `delta`, `type`) VALUES
('blog', 'recent', 'news'),
('views', 'handbook-block', 'blog'),
('views', 'handbook-block', 'news'),
('views', 'handbook-block', 'reviews'),
('views', 'handbook-block', 'servises');
