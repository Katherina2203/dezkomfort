
-- --------------------------------------------------------

--
-- Структура таблицы `cache_admin_menu`
--

CREATE TABLE `cache_admin_menu` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cache table for Administration menu to store client-side...';

--
-- Дамп данных таблицы `cache_admin_menu`
--

INSERT INTO `cache_admin_menu` (`cid`, `data`, `expire`, `created`, `serialized`) VALUES
('admin_menu:1:-ywkCN_5KG32okiG4LTo2VzCs4angzqAZ68Ndz5TPxk:ru', 0x3064386331373831663837663964323531636332333631336666336337386230, 0, 1492520648, 0);
