
-- --------------------------------------------------------

--
-- Структура таблицы `cache_path`
--

CREATE TABLE `cache_path` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cache table for path alias lookup.';

--
-- Дамп данных таблицы `cache_path`
--

INSERT INTO `cache_path` (`cid`, `data`, `expire`, `created`, `serialized`) VALUES
('admin', 0x613a323a7b693a303b733a31313a22757365722f6c6f676f7574223b693a313b733a363a22757365722f31223b7d, 1492607037, 1492520637, 1),
('admin/config/administration/admin_menu', 0x613a333a7b693a303b733a31313a22757365722f6c6f676f7574223b693a313b733a363a22757365722f31223b693a323b733a383a226e6f64652f616464223b7d, 1492607062, 1492520662, 1);
