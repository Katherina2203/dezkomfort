
-- --------------------------------------------------------

--
-- Структура таблицы `captcha_points`
--

CREATE TABLE `captcha_points` (
  `form_id` varchar(128) NOT NULL DEFAULT '' COMMENT 'The form_id of the form to add a CAPTCHA to.',
  `module` varchar(64) DEFAULT NULL COMMENT 'The module that provides the challenge.',
  `captcha_type` varchar(64) DEFAULT NULL COMMENT 'The challenge type to use.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This table describes which challenges should be added to...';
