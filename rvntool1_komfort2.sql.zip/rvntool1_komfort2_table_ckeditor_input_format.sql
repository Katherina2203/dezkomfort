
-- --------------------------------------------------------

--
-- Структура таблицы `ckeditor_input_format`
--

CREATE TABLE `ckeditor_input_format` (
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT 'Name of the CKEditor role',
  `format` varchar(128) NOT NULL DEFAULT '' COMMENT 'Drupal filter format ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores CKEditor input format assignments';

--
-- Дамп данных таблицы `ckeditor_input_format`
--

INSERT INTO `ckeditor_input_format` (`name`, `format`) VALUES
('Advanced', 'filtered_html'),
('Full', 'full_html');
