
-- --------------------------------------------------------

--
-- Структура таблицы `field_data_field_pic_handbook`
--

CREATE TABLE `field_data_field_pic_handbook` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) UNSIGNED NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) UNSIGNED NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_pic_handbook_fid` int(10) UNSIGNED DEFAULT NULL COMMENT 'The file_managed.fid being referenced in this field.',
  `field_pic_handbook_alt` varchar(512) DEFAULT NULL COMMENT 'Alternative image text, for the image’s ’alt’ attribute.',
  `field_pic_handbook_title` varchar(1024) DEFAULT NULL COMMENT 'Image title text, for the image’s ’title’ attribute.',
  `field_pic_handbook_width` int(10) UNSIGNED DEFAULT NULL COMMENT 'The width of the image in pixels.',
  `field_pic_handbook_height` int(10) UNSIGNED DEFAULT NULL COMMENT 'The height of the image in pixels.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 9 (field_pic_handbook)';

--
-- Дамп данных таблицы `field_data_field_pic_handbook`
--

INSERT INTO `field_data_field_pic_handbook` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_pic_handbook_fid`, `field_pic_handbook_alt`, `field_pic_handbook_title`, `field_pic_handbook_width`, `field_pic_handbook_height`) VALUES
('node', 'handbook', 0, 21, 21, 'und', 0, 50, '', '', 430, 318),
('node', 'handbook', 0, 22, 22, 'und', 0, 48, '', '', 174, 166),
('node', 'handbook', 0, 28, 28, 'und', 0, 49, '', '', 294, 212);
