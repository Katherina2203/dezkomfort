
-- --------------------------------------------------------

--
-- Структура таблицы `file_managed`
--

CREATE TABLE `file_managed` (
  `fid` int(10) UNSIGNED NOT NULL COMMENT 'File ID.',
  `uid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The users.uid of the user who is associated with the file.',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the file with no path components. This may differ from the basename of the URI if the file is renamed to avoid overwriting an existing file.',
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'The URI to access the file (either local or remote).',
  `filemime` varchar(255) NOT NULL DEFAULT '' COMMENT 'The file’s MIME type.',
  `filesize` bigint(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The size of the file in bytes.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A field indicating the status of the file. Two status are defined in core: temporary (0) and permanent (1). Temporary files older than DRUPAL_MAXIMUM_TEMP_FILE_AGE will be removed during a cron run.',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp for when the file was added.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores information for uploaded files.';

--
-- Дамп данных таблицы `file_managed`
--

INSERT INTO `file_managed` (`fid`, `uid`, `filename`, `uri`, `filemime`, `filesize`, `status`, `timestamp`) VALUES
(17, 1, 'img_6491_.jpg', 'public://img_6491_.jpg', 'image/jpeg', 118686, 1, 1465816504),
(19, 1, 'img_6491_.jpg', 'public://field/image/img_6491_.jpg', 'image/jpeg', 118686, 1, 1465816678),
(20, 1, 'img_6580.jpg', 'public://field/image/img_6580.jpg', 'image/jpeg', 103012, 1, 1465816840),
(21, 1, 'plesen_0.jpg', 'public://field/image/plesen_0.jpg', 'image/jpeg', 70401, 1, 1465816937),
(22, 1, 'deratizaciya.png', 'public://field/image/deratizaciya.png', 'image/png', 86764, 1, 1465817008),
(23, 1, 'suhoy_tuman.jpg', 'public://field/image/suhoy_tuman.jpg', 'image/jpeg', 18141, 1, 1465817091),
(24, 1, 'suhoy_t.jpg', 'public://field/image/suhoy_t.jpg', 'image/jpeg', 28630, 1, 1465817150),
(25, 1, 'images_1.jpg', 'public://field/image/images_1.jpg', 'image/jpeg', 11606, 1, 1465817218),
(26, 1, 'dd.jpg', 'public://field/image/dd.jpg', 'image/jpeg', 3252, 1, 1465817262),
(27, 1, 'plesen4.jpg', 'public://field/image/plesen4.jpg', 'image/jpeg', 42767, 1, 1465817440),
(28, 1, 'desinsection.jpg', 'public://pictures/yslugi/desinsection.jpg', 'image/jpeg', 11898, 1, 1465820288),
(29, 1, 'ur_lic.png', 'public://pictures/yslugi/ur_lic.png', 'image/png', 162081, 1, 1465887792),
(30, 1, 'vanna_.png', 'public://pictures/yslugi/vanna_.png', 'image/png', 81396, 1, 1465888223),
(31, 1, 'girl_sale.png', 'public://girl_sale.png', 'image/png', 69292, 1, 1465893342),
(32, 1, 'no-photo.png', 'public://default_images/no-photo.png', 'image/png', 792, 1, 1465896513),
(34, 1, 'no-photo.png', 'public://reviews/no-photo.png', 'image/png', 792, 1, 1465901694),
(35, 1, 'no-photo.png', 'public://reviews/no-photo_0.png', 'image/png', 792, 1, 1465901916),
(36, 1, '5-stars-rating-3d-stars-icons.jpg', 'public://reviews/5-stars-rating-3d-stars-icons.jpg', 'image/jpeg', 3632, 1, 1465904718),
(37, 1, 'kyivstar.png', 'public://pictures/kyivstar.png', 'image/png', 2684, 1, 1465912201),
(38, 1, 'life.png', 'public://pictures/life.png', 'image/png', 12519, 1, 1465912227),
(39, 1, 'mts.png', 'public://pictures/mts.png', 'image/png', 826, 1, 1465912243),
(43, 1, 'dezinf.jpg', 'public://pictures/yslugi/dezinf.jpg', 'image/jpeg', 7628, 1, 1465973257),
(44, 1, 'motto.net.ua-47157.jpg', 'public://pictures/motto.net.ua-47157.jpg', 'image/jpeg', 53202, 1, 1465978112),
(45, 1, 'competitive.jpg', 'public://pictures/competitive.jpg', 'image/jpeg', 51081, 1, 1465978431),
(46, 1, 'katya.jpg', 'public://reviews/katya.jpg', 'image/jpeg', 14645, 1, 1465994718),
(47, 1, 'dd_0.jpg', 'public://pictures/news/dd_0.jpg', 'image/jpeg', 3252, 1, 1466156421),
(48, 1, '992_big.jpg', 'public://992_big.jpg', 'image/jpeg', 8510, 1, 1468409079),
(49, 1, 'mol.jpg', 'public://mol.jpg', 'image/jpeg', 9791, 1, 1468409117),
(50, 1, 'komar_.jpg', 'public://komar_.jpg', 'image/jpeg', 11124, 1, 1468409281),
(51, 1, 'backup_migrate-7.x-3.1.zip', 'temporary://backup_migrate-7.x-3.1.zip', 'application/zip', 122576, 0, 1492519392);
