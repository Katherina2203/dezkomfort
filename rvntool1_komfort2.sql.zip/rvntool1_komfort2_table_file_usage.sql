
-- --------------------------------------------------------

--
-- Структура таблицы `file_usage`
--

CREATE TABLE `file_usage` (
  `fid` int(10) UNSIGNED NOT NULL COMMENT 'File ID.',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the module that is using the file.',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT 'The name of the object type in which the file is used.',
  `id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The primary key of the object using the file.',
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The number of times this file is used by this object.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Track where a file is used.';

--
-- Дамп данных таблицы `file_usage`
--

INSERT INTO `file_usage` (`fid`, `module`, `type`, `id`, `count`) VALUES
(17, 'file', 'node', 3, 1),
(19, 'file', 'node', 11, 1),
(20, 'file', 'node', 6, 1),
(21, 'file', 'node', 14, 1),
(22, 'file', 'node', 15, 1),
(23, 'file', 'node', 16, 1),
(24, 'file', 'node', 17, 1),
(25, 'file', 'node', 18, 1),
(26, 'file', 'node', 19, 1),
(27, 'file', 'node', 20, 1),
(28, 'imce', 'file', 28, 1),
(29, 'imce', 'file', 29, 1),
(30, 'imce', 'file', 30, 1),
(31, 'file', 'node', 4, 1),
(32, 'image', 'default_image', 8, 1),
(34, 'file', 'node', 47, 1),
(35, 'file', 'node', 48, 1),
(36, 'file', 'node', 49, 1),
(37, 'imce', 'file', 37, 1),
(38, 'imce', 'file', 38, 1),
(39, 'imce', 'file', 39, 1),
(43, 'imce', 'file', 43, 1),
(44, 'imce', 'file', 44, 1),
(45, 'imce', 'file', 45, 1),
(46, 'file', 'node', 49, 1),
(47, 'imce', 'file', 47, 1),
(48, 'file', 'node', 22, 1),
(49, 'file', 'node', 28, 1),
(50, 'file', 'node', 21, 1);
