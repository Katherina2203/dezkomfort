
-- --------------------------------------------------------

--
-- Структура таблицы `forum`
--

CREATE TABLE `forum` (
  `nid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The node.nid of the node.',
  `vid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Primary Key: The node.vid of the node.',
  `tid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The taxonomy_term_data.tid of the forum term assigned to the node.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores the relationship of nodes to forum terms.';
