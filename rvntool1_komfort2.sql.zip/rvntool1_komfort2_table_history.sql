
-- --------------------------------------------------------

--
-- Структура таблицы `history`
--

CREATE TABLE `history` (
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that read the node nid.',
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'The node.nid that was read.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp at which the read occurred.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='A record of which users have read which nodes.';

--
-- Дамп данных таблицы `history`
--

INSERT INTO `history` (`uid`, `nid`, `timestamp`) VALUES
(1, 17, 1492516766),
(1, 19, 1492515483),
(1, 30, 1492515869),
(1, 31, 1492515786),
(1, 42, 1492515873);
