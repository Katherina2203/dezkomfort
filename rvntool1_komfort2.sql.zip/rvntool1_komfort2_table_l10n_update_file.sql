
-- --------------------------------------------------------

--
-- Структура таблицы `l10n_update_file`
--

CREATE TABLE `l10n_update_file` (
  `project` varchar(255) NOT NULL COMMENT 'A unique short name to identify the project.',
  `language` varchar(12) NOT NULL COMMENT 'Reference to the languages.language for this translation.',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT 'File origin: download or localfile',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT 'Link to translation file for download.',
  `fileurl` varchar(255) NOT NULL DEFAULT '' COMMENT 'Link to translation file for download.',
  `uri` varchar(255) NOT NULL DEFAULT '' COMMENT 'File system path for importing the file.',
  `timestamp` int(11) DEFAULT '0' COMMENT 'Unix timestamp of the time the file was downloaded or saved to disk. Zero if not yet downloaded',
  `version` varchar(128) NOT NULL DEFAULT '' COMMENT 'Version tag of the downloaded file.',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'Status flag. TBD',
  `last_checked` int(11) DEFAULT '0' COMMENT 'Unix timestamp of the last time this translation was downloaded from or checked at remote server and confirmed to be the most recent release available.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='File and download information for project translations.';

--
-- Дамп данных таблицы `l10n_update_file`
--

INSERT INTO `l10n_update_file` (`project`, `language`, `type`, `filename`, `fileurl`, `uri`, `timestamp`, `version`, `status`, `last_checked`) VALUES
('admin_menu', 'ru', '', '', '', '', 0, '7.x-3.0-rc5', 1, 0),
('backup_migrate', 'ru', 'local', 'backup_migrate-7.x-3.1.ru.po', '', 'translations://backup_migrate-7.x-3.1.ru.po', 1492520574, '7.x-3.1', 1, 1492520575),
('bootstrap_business', 'ru', 'local', 'bootstrap_business-7.x-1.1.ru.po', '', 'translations://bootstrap_business-7.x-1.1.ru.po', 1465808076, '7.x-1.1', 1, 1465808076),
('captcha', 'ru', 'local', 'captcha-7.x-1.3.ru.po', '', 'translations://captcha-7.x-1.3.ru.po', 1466155801, '7.x-1.3', 1, 1466155800),
('ckeditor', 'ru', 'local', 'ckeditor-7.x-1.17.ru.po', '', 'translations://ckeditor-7.x-1.17.ru.po', 1465814038, '7.x-1.17', 1, 1465814051),
('colorbox', 'ru', 'local', 'colorbox-7.x-2.10.ru.po', '', 'translations://colorbox-7.x-2.x.ru.po', 1465810837, '7.x-2.10', 1, 1465810836),
('ctools', 'ru', '', '', '', '', 0, '7.x-1.9', 1, 0),
('drupal', 'ru', 'local', 'drupal-7.41.ru.po', '', 'translations://drupal-7.41.ru.po', 1465808080, '7.41', 1, 1465808345),
('imce', 'ru', '', '', '', '', 0, '7.x-1.10', 1, 0),
('jquery_update', 'ru', 'local', 'jquery_update-7.x-2.7.ru.po', '', 'translations://jquery_update-7.x-2.7.ru.po', 1465808348, '7.x-2.7', 1, 1465808347),
('l10n_update', 'ru', 'local', 'l10n_update-7.x-2.0.ru.po', '', 'translations://l10n_update-7.x-2.0.ru.po', 1465808350, '7.x-2.0', 1, 1465808352),
('libraries', 'ru', 'local', 'libraries-7.x-2.2.ru.po', '', 'translations://libraries-7.x-2.2.ru.po', 1465808360, '7.x-2.2', 1, 1465808359),
('link', 'ru', '', '', '', '', 0, '7.x-1.4', 1, 0),
('metatag', 'ru', '', '', '', '', 0, '7.x-1.21', 1, 0),
('panels', 'ru', 'local', 'panels-7.x-3.5.ru.po', '', 'translations://panels-7.x-3.5.ru.po', 1468836573, '7.x-3.5', 1, 1468836574),
('pathauto', 'ru', '', '', '', '', 0, '7.x-1.3', 1, 0),
('simplenews', 'ru', 'local', 'simplenews-7.x-1.1.ru.po', '', 'translations://simplenews-7.x-1.1.ru.po', 1467294351, '7.x-1.1', 1, 1467294351),
('superfish', 'ru', 'local', 'superfish-7.x-1.9.ru.po', '', 'translations://superfish-7.x-1.9.ru.po', 1465808362, '7.x-1.9', 1, 1465808362),
('token', 'ru', '', '', '', '', 0, '7.x-1.6', 1, 0),
('transliteration', 'ru', 'local', 'transliteration-7.x-3.2.ru.po', '', 'translations://transliteration-7.x-3.2.ru.po', 1465810830, '7.x-3.2', 1, 1465810831),
('views', 'ru', '', '', '', '', 0, '7.x-3.16', 1, 0),
('xmlsitemap', 'ru', 'local', 'xmlsitemap-7.x-2.3.ru.po', '', 'translations://xmlsitemap-7.x-2.3.ru.po', 1465903340, '7.x-2.3', 1, 1465903339);
