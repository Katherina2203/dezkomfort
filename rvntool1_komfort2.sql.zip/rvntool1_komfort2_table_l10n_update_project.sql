
-- --------------------------------------------------------

--
-- Структура таблицы `l10n_update_project`
--

CREATE TABLE `l10n_update_project` (
  `name` varchar(255) NOT NULL COMMENT 'A unique short name to identify the project.',
  `project_type` varchar(50) NOT NULL COMMENT 'Project type, may be core, module, theme',
  `core` varchar(128) NOT NULL DEFAULT '' COMMENT 'Core compatibility string for this project.',
  `version` varchar(128) NOT NULL DEFAULT '' COMMENT 'Human readable name for project used on the interface.',
  `l10n_path` varchar(255) NOT NULL DEFAULT '' COMMENT 'Server path this project updates.',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'Status flag. If TRUE, translations of this module will be updated.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Update information for project translations.';

--
-- Дамп данных таблицы `l10n_update_project`
--

INSERT INTO `l10n_update_project` (`name`, `project_type`, `core`, `version`, `l10n_path`, `status`) VALUES
('admin_menu', 'module', '7.x', '7.x-3.0-rc5', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('backup_migrate', 'module', '7.x', '7.x-3.1', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('bootstrap_business', 'theme', '7.x', '7.x-1.1', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('captcha', 'module', '7.x', '7.x-1.3', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 0),
('ckeditor', 'module', '7.x', '7.x-1.17', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('colorbox', 'module', '7.x', '7.x-2.12', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('ctools', 'module', '7.x', '7.x-1.9', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('drupal', 'core', '7.x', '7.44', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('imce', 'module', '7.x', '7.x-1.10', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('jquery_update', 'module', '7.x', '7.x-2.7', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('l10n_update', 'module', '7.x', '7.x-2.0', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('libraries', 'module', '7.x', '7.x-2.3', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('link', 'module', '7.x', '7.x-1.4', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('metatag', 'module', '7.x', '7.x-1.21', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('panels', 'module', '7.x', '7.x-3.9', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('pathauto', 'module', '7.x', '7.x-1.3', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('simplenews', 'module', '7.x', '7.x-1.1', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('superfish', 'module', '7.x', '7.x-1.9', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('token', 'module', '7.x', '7.x-1.6', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('transliteration', 'module', '7.x', '7.x-3.2', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('views', 'module', '7.x', '7.x-3.16', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1),
('xmlsitemap', 'module', '7.x', '7.x-2.3', 'http://ftp.drupal.org/files/translations/%core/%project/%project-%release.%language.po', 1);
