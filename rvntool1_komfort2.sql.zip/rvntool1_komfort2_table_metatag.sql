
-- --------------------------------------------------------

--
-- Структура таблицы `metatag`
--

CREATE TABLE `metatag` (
  `entity_type` varchar(32) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to.',
  `entity_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The entity id this data is attached to.',
  `revision_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The revision_id for the entity object this data is attached to.',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language of the tag.',
  `data` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `metatag`
--

INSERT INTO `metatag` (`entity_type`, `entity_id`, `revision_id`, `language`, `data`) VALUES
('node', 4, 4, 'und', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a35333a22d181d0bad0b8d0b4d0bad0b82c20d0bdd0b020d0bed0b1d180d0b0d0b1d0bed182d0bad1832c20d0bad0b2d0b0d180d182d0b8d180223b7d7d),
('node', 20, 20, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a34393a22d0bfd0bbd0b5d181d0b5d0bdd18c2c20d0b1d0bed180d18cd0b1d0b02c20d0b220d185d0b0d180d18cd0bad0bed0b2d0b5223b7d7d),
('node', 27, 27, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a39383a22d0b1d0bbd0bed185d0b82c20d0b1d0bed180d18cd0b1d0b02c20d0b220d185d0b0d180d18cd0bad0bed0b2d0b52c20d0b220d0bad0b2d0b0d180d182d0b8d180d0b52c20d0bad0bed0bcd184d0bed180d1822c20d0b2d18bd0b2d0b5d181d182d0b8223b7d7d),
('node', 30, 30, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a3132393a22d0bfd180d0b5d0bfd0b0d180d0b0d182d18b2c20d0b1d0b5d0b7d0bed0bfd0b0d181d0bdd18bd0b52c20d183d0bdd0b8d187d182d0bed0b6d0b5d0bdd0b8d0b52c20d0b3d180d18bd0b7d183d0bdd0bed0b22c20d0bdd0b020d0bed182d0bad180d18bd182d18bd1852c20d182d0b5d180d180d0b8d182d0bed180d0b8d18fd185223b7d7d),
('node', 31, 31, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a3133323a22d0b1d0bed180d18cd0b1d0b02c20d18120d0bad0bed0bcd0b0d180d0b0d0bcd0b82c20d0bdd0b020d0bed182d0bad180d18bd182d18bd18520d182d0b5d180d180d0b8d182d0bed180d0b8d18fd1852c20d181d0b0d0b4d0bed0b2d18bd1852c20d183d187d0b0d181d182d0bad0b0d1852c20d18120d0bad0bbd0b5d189d0b0d0bcd0b8223b7d7d),
('node', 32, 32, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a3134363a22d183d181d0bbd183d0b3d0b820d0b4d0bbd18f20d18ed180d0b8d0b4d0b8d187d0b5d181d0bad0b8d18520d0bbd0b8d1862c20d183d0bdd0b8d187d182d0bed0b6d0b5d0bdd0b8d0b520d182d0b0d180d0b0d0bad0b0d0bdd0bed0b22c20d0bad0bbd0bed0bfd0bed0b22c20d0bdd0b0d181d0b5d0bad0bed0bcd18bd18520d0b220d185d0b0d180d18cd0bad0bed0b2d0b5223b7d7d),
('node', 35, 35, 'ru', 0x613a313a7b733a383a226b6579776f726473223b613a313a7b733a353a2276616c7565223b733a3137373a22d183d0bdd0b8d187d182d0bed0b6d0b5d0bdd0b8d0b520d0bfd0b0d180d0b0d0b7d0b8d182d0bed0b22c20d0b4d0b5d0b7d0b8d0bdd184d0b5d0bad186d0b8d18f20d0b220d0b4d0bed0bcd0b0d18520d0b820d0bad0b2d0b0d180d182d0b8d180d0b0d1852c20d0b4d0b5d0b7d0b8d0bdd184d0b5d0bad186d0b8d18f20d0b220d0a5d0b0d180d18cd0bad0bed0b2d0b52c20d0b1d0bed180d18cd0b1d0b020d18120d0b3d180d0b8d0b1d0bad0bed0bc223b7d7d);
