
-- --------------------------------------------------------

--
-- Структура таблицы `metatag_config`
--

CREATE TABLE `metatag_config` (
  `cid` int(10) UNSIGNED NOT NULL COMMENT 'The primary identifier for a metatag configuration set.',
  `instance` varchar(255) NOT NULL DEFAULT '' COMMENT 'The machine-name of the configuration, typically entity-type:bundle.',
  `config` longblob NOT NULL COMMENT 'Serialized data containing the meta tag configuration.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Storage of meta tag configuration and defaults.';
