
-- --------------------------------------------------------

--
-- Структура таблицы `node`
--

CREATE TABLE `node` (
  `nid` int(10) UNSIGNED NOT NULL COMMENT 'The primary identifier for a node.',
  `vid` int(10) UNSIGNED DEFAULT NULL COMMENT 'The current node_revision.vid version identifier.',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT 'The node_type.type of this node.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The languages.language of this node.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title of this node, always treated as non-markup plain text.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that owns this node; initially, this is the user that created it.',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'Boolean indicating whether the node is published (visible to non-administrators).',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was created.',
  `changed` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was most recently saved.',
  `comment` int(11) NOT NULL DEFAULT '0' COMMENT 'Whether comments are allowed on this node: 0 = no, 1 = closed (read only), 2 = open (read/write).',
  `promote` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node should be displayed on the front page.',
  `sticky` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node should be displayed at the top of lists in which it appears.',
  `tnid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The translation set id for this node, which equals the node id of the source post in each set.',
  `translate` int(11) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this translation page needs to be updated.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The base table for nodes.';

--
-- Дамп данных таблицы `node`
--

INSERT INTO `node` (`nid`, `vid`, `type`, `language`, `title`, `uid`, `status`, `created`, `changed`, `comment`, `promote`, `sticky`, `tnid`, `translate`) VALUES
(3, 3, 'blog', 'und', 'Как подготовить площадь к приезду специалиста', 1, 1, 1381480633, 1468828971, 2, 0, 0, 0, 0),
(4, 4, 'blog', 'und', 'Акция на обработку квартир', 1, 1, 1381480898, 1468828927, 2, 0, 0, 0, 0),
(6, 6, 'news', 'und', 'Дезинфекция на практике', 1, 1, 1381419832, 1468829099, 2, 0, 0, 0, 0),
(11, 11, 'news', 'und', 'Как подготовить площадь к приезду специалиста', 1, 1, 1382430950, 1468828954, 2, 0, 0, 0, 0),
(13, 13, 'page', 'und', 'О нас', 1, 1, 1384864695, 1465809519, 1, 0, 0, 0, 0),
(14, 14, 'news', 'ru', 'Что мы знаем о плесени?', 1, 1, 1465816937, 1468828904, 2, 0, 0, 0, 0),
(15, 15, 'news', 'ru', '﻿Преимущества используемых препаратов', 1, 1, 1465817008, 1468828869, 2, 0, 0, 0, 0),
(16, 16, 'news', 'ru', 'Обработка сухой туман', 1, 1, 1465817091, 1468828850, 2, 0, 0, 0, 0),
(17, 17, 'news', 'ru', 'Что уничтожает сухой туман?', 1, 1, 1465817150, 1492515997, 2, 0, 0, 0, 0),
(18, 18, 'news', 'ru', 'Клещи в Харькове', 1, 1, 1465817218, 1468828758, 2, 0, 0, 0, 0),
(19, 19, 'news', 'ru', 'Профессиональные услуги Дезинсекции', 1, 1, 1465817262, 1468828722, 2, 0, 0, 0, 0),
(20, 20, 'news', 'ru', 'Проблема устранения плесени', 0, 1, 1465817440, 1468828697, 2, 0, 0, 0, 0),
(21, 21, 'handbook', 'ru', 'Комары', 1, 1, 1465817579, 1468409281, 1, 0, 0, 0, 0),
(22, 22, 'handbook', 'ru', 'Плесень', 1, 1, 1465817725, 1468409079, 1, 0, 0, 0, 0),
(23, 23, 'handbook', 'ru', 'Тараканы', 1, 1, 1465817784, 1465817784, 1, 0, 0, 0, 0),
(24, 24, 'handbook', 'ru', 'Муравьи', 1, 1, 1465817867, 1465817867, 1, 0, 0, 0, 0),
(25, 25, 'handbook', 'ru', 'Клопы', 1, 1, 1465817996, 1465817996, 1, 0, 0, 0, 0),
(26, 26, 'handbook', 'ru', 'Клещи', 1, 1, 1465818077, 1465818077, 1, 0, 0, 0, 0),
(27, 27, 'handbook', 'ru', 'Блохи', 1, 1, 1465818122, 1465997100, 1, 0, 0, 0, 0),
(28, 28, 'handbook', 'ru', 'Моль', 1, 1, 1465818164, 1468409117, 1, 0, 0, 0, 0),
(29, 29, 'servises', 'ru', 'Уничтожение комаров', 1, 1, 1465818322, 1468396459, 1, 0, 0, 0, 0),
(30, 30, 'page', 'ru', 'Услуги', 1, 1, 1465818425, 1468396233, 1, 0, 0, 0, 0),
(31, 31, 'servises', 'ru', 'Услуги для открытых территорий', 1, 1, 1465818510, 1467293473, 1, 0, 0, 0, 0),
(32, 32, 'servises', 'ru', 'Услуги для юридических лиц', 1, 1, 1465818560, 1467293518, 1, 0, 0, 0, 0),
(33, 33, 'servises', 'ru', 'Насекомые в кафе и ресторане', 1, 1, 1465818649, 1465818649, 1, 0, 0, 0, 0),
(34, 34, 'servises', 'ru', 'Обработка участков от клещей', 1, 1, 1465818711, 1465818711, 1, 0, 0, 0, 0),
(35, 35, 'servises', 'ru', 'Услуги для физических лиц', 1, 1, 1465818751, 1467293942, 1, 0, 0, 0, 0),
(36, 36, 'servises', 'ru', 'Уничтожение тараканов', 1, 1, 1465818796, 1465818796, 1, 0, 0, 0, 0),
(37, 37, 'servises', 'ru', 'Уничтожение клопов в Харькове', 1, 1, 1465818924, 1465818924, 1, 0, 0, 0, 0),
(38, 38, 'servises', 'ru', 'Дезинфекция мебели', 1, 1, 1465818980, 1465818980, 1, 0, 0, 0, 0),
(39, 39, 'servises', 'ru', 'Дезинфекция воздушных судов', 1, 1, 1465819428, 1465819428, 1, 0, 0, 0, 0),
(40, 40, 'servises', 'ru', 'Дезинфекция в стоматологических кабинетах', 1, 1, 1465819549, 1465819549, 1, 0, 0, 0, 0),
(41, 41, 'servises', 'ru', 'Борьба и уничтожение муравьев', 1, 1, 1465819644, 1465819644, 1, 0, 0, 0, 0),
(42, 42, 'page', 'ru', 'Стоимость услуг', 1, 1, 1465820323, 1468568995, 1, 0, 0, 0, 0),
(43, 43, 'page', 'ru', 'Страница не найдена', 1, 1, 1465821300, 1465821624, 1, 0, 0, 0, 0),
(44, 44, 'page', 'ru', 'Нет доступа', 1, 1, 1465821554, 1465821586, 1, 0, 0, 0, 0),
(45, 45, 'page', 'ru', 'Санитарная служба Харькова “Комфорт”', 1, 0, 1465825442, 1465977574, 1, 0, 0, 0, 0),
(46, 46, 'page', 'ru', 'Скидки и акции', 1, 1, 1465846528, 1465892958, 1, 0, 0, 0, 0),
(47, 47, 'reviews', 'ru', 'Муравьев нет', 1, 1, 1465901694, 1468828618, 2, 0, 0, 0, 0),
(48, 48, 'reviews', 'ru', 'Рекомендую', 1, 1, 1465901916, 1468828654, 2, 0, 0, 0, 0),
(49, 49, 'reviews', 'ru', 'Отзывы', 1, 1, 1465904718, 1468828556, 2, 0, 0, 0, 0),
(51, 51, 'panel', 'ru', 'News panel', 1, 0, 1470297812, 1470297834, 2, 0, 0, 0, 0),
(52, 52, 'page', 'ru', 'Комфорт', 1, 1, 1470300326, 1470300326, 1, 1, 0, 0, 0);
