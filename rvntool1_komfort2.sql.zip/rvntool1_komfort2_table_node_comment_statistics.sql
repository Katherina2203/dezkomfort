
-- --------------------------------------------------------

--
-- Структура таблицы `node_comment_statistics`
--

CREATE TABLE `node_comment_statistics` (
  `nid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The node.nid for which the statistics are compiled.',
  `cid` int(11) NOT NULL DEFAULT '0' COMMENT 'The comment.cid of the last comment.',
  `last_comment_timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp of the last comment that was posted within this node, from comment.changed.',
  `last_comment_name` varchar(60) DEFAULT NULL COMMENT 'The name of the latest author to post a comment on this node, from comment.name.',
  `last_comment_uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The user ID of the latest author to post a comment on this node, from comment.uid.',
  `comment_count` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The total number of comments on this node.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maintains statistics of node and comments posts to show ...';

--
-- Дамп данных таблицы `node_comment_statistics`
--

INSERT INTO `node_comment_statistics` (`nid`, `cid`, `last_comment_timestamp`, `last_comment_name`, `last_comment_uid`, `comment_count`) VALUES
(3, 0, 1381480633, NULL, 1, 0),
(4, 0, 1381480898, '', 1, 0),
(6, 0, 1381592632, NULL, 1, 0),
(11, 11, 1382433698, '', 1, 6),
(13, 0, 1384864695, NULL, 1, 0),
(14, 0, 1465816937, NULL, 1, 0),
(15, 0, 1465817008, NULL, 1, 0),
(16, 0, 1465817091, NULL, 1, 0),
(17, 0, 1465817150, NULL, 1, 0),
(18, 0, 1465817218, NULL, 1, 0),
(19, 0, 1465817262, NULL, 1, 0),
(20, 0, 1465817440, NULL, 1, 0),
(21, 0, 1465817579, NULL, 1, 0),
(22, 0, 1465817725, NULL, 1, 0),
(23, 0, 1465817784, NULL, 1, 0),
(24, 0, 1465817867, NULL, 1, 0),
(25, 0, 1465817996, NULL, 1, 0),
(26, 0, 1465818077, NULL, 1, 0),
(27, 0, 1465818122, NULL, 1, 0),
(28, 0, 1465818164, NULL, 1, 0),
(29, 0, 1465818322, NULL, 1, 0),
(30, 0, 1465818425, NULL, 1, 0),
(31, 0, 1465818510, NULL, 1, 0),
(32, 0, 1465818560, NULL, 1, 0),
(33, 0, 1465818649, NULL, 1, 0),
(34, 0, 1465818711, NULL, 1, 0),
(35, 0, 1465818751, NULL, 1, 0),
(36, 0, 1465818796, NULL, 1, 0),
(37, 0, 1465818924, NULL, 1, 0),
(38, 0, 1465818980, NULL, 1, 0),
(39, 0, 1465819428, NULL, 1, 0),
(40, 0, 1465819549, NULL, 1, 0),
(41, 0, 1465819644, NULL, 1, 0),
(42, 0, 1465820323, NULL, 1, 0),
(43, 0, 1465821300, NULL, 1, 0),
(44, 0, 1465821554, NULL, 1, 0),
(45, 0, 1465825442, NULL, 1, 0),
(46, 0, 1465846528, NULL, 1, 0),
(47, 0, 1465901694, NULL, 1, 0),
(48, 0, 1465901916, NULL, 1, 0),
(49, 0, 1465904718, NULL, 1, 0),
(51, 0, 1470297812, NULL, 1, 0),
(52, 0, 1470300326, NULL, 1, 0);
