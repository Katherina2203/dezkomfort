
-- --------------------------------------------------------

--
-- Структура таблицы `node_counter`
--

CREATE TABLE `node_counter` (
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'The node.nid for these statistics.',
  `totalcount` bigint(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The total number of times the node has been viewed.',
  `daycount` mediumint(8) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The total number of times the node has been viewed today.',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The most recent time the node has been viewed.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Access statistics for nodes.';
