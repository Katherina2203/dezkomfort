
-- --------------------------------------------------------

--
-- Структура таблицы `panels_allowed_types`
--

CREATE TABLE `panels_allowed_types` (
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the module requiring allowed type settings.',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT 'Ctools content type to allow.',
  `allowed` tinyint(4) DEFAULT '1' COMMENT 'A boolean for if the type is allowed or not.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
