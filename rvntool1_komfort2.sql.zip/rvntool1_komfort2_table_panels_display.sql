
-- --------------------------------------------------------

--
-- Структура таблицы `panels_display`
--

CREATE TABLE `panels_display` (
  `did` int(11) NOT NULL,
  `layout` varchar(255) DEFAULT '',
  `layout_settings` longtext,
  `panel_settings` longtext,
  `cache` text,
  `title` varchar(255) DEFAULT '',
  `hide_title` tinyint(4) DEFAULT '0',
  `title_pane` int(11) DEFAULT '0',
  `uuid` char(36) DEFAULT NULL,
  `storage_type` varchar(255) DEFAULT '',
  `storage_id` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `panels_display`
--

INSERT INTO `panels_display` (`did`, `layout`, `layout_settings`, `panel_settings`, `cache`, `title`, `hide_title`, `title_pane`, `uuid`, `storage_type`, `storage_id`) VALUES
(1, 'twocol', 'a:0:{}', 'a:0:{}', 'a:0:{}', '', 0, 0, '5c2c09c9-0598-4266-8c11-d9b6be5be549', 'panels_node', '51');
