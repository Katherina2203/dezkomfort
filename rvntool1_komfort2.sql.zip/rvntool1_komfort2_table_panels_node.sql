
-- --------------------------------------------------------

--
-- Структура таблицы `panels_node`
--

CREATE TABLE `panels_node` (
  `nid` int(11) NOT NULL DEFAULT '0',
  `css_id` varchar(255) DEFAULT NULL,
  `did` int(11) NOT NULL,
  `pipeline` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `panels_node`
--

INSERT INTO `panels_node` (`nid`, `css_id`, `did`, `pipeline`) VALUES
(51, 'news-panel', 1, 'standard');
