
-- --------------------------------------------------------

--
-- Структура таблицы `panels_pane`
--

CREATE TABLE `panels_pane` (
  `pid` int(11) NOT NULL,
  `did` int(11) NOT NULL DEFAULT '0',
  `panel` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  `subtype` varchar(255) DEFAULT '',
  `shown` tinyint(4) DEFAULT '1',
  `access` longtext,
  `configuration` longtext,
  `cache` longtext,
  `style` longtext,
  `css` longtext,
  `extras` longtext,
  `position` smallint(6) DEFAULT '0',
  `locks` longtext,
  `uuid` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
