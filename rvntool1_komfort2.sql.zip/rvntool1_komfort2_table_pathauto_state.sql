
-- --------------------------------------------------------

--
-- Структура таблицы `pathauto_state`
--

CREATE TABLE `pathauto_state` (
  `entity_type` varchar(32) NOT NULL COMMENT 'An entity type.',
  `entity_id` int(10) UNSIGNED NOT NULL COMMENT 'An entity ID.',
  `pathauto` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The automatic alias status of the entity.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The status of each entity alias (whether it was...';

--
-- Дамп данных таблицы `pathauto_state`
--

INSERT INTO `pathauto_state` (`entity_type`, `entity_id`, `pathauto`) VALUES
('node', 3, 0),
('node', 4, 0),
('node', 6, 0),
('node', 11, 0),
('node', 14, 1),
('node', 15, 1),
('node', 16, 1),
('node', 17, 1),
('node', 18, 1),
('node', 19, 1),
('node', 20, 1),
('node', 21, 1),
('node', 22, 1),
('node', 23, 1),
('node', 24, 1),
('node', 25, 1),
('node', 26, 1),
('node', 27, 1),
('node', 28, 1),
('node', 29, 1),
('node', 30, 1),
('node', 31, 1),
('node', 32, 0),
('node', 33, 1),
('node', 34, 1),
('node', 35, 1),
('node', 36, 1),
('node', 37, 1),
('node', 38, 1),
('node', 39, 1),
('node', 40, 1),
('node', 41, 1),
('node', 42, 1),
('node', 43, 1),
('node', 44, 1),
('node', 45, 0),
('node', 46, 1),
('node', 47, 1),
('node', 48, 1),
('node', 49, 1),
('node', 51, 1),
('node', 52, 1),
('taxonomy_term', 1, 1),
('taxonomy_term', 2, 1),
('taxonomy_term', 6, 1),
('taxonomy_term', 7, 1),
('taxonomy_term', 8, 1),
('taxonomy_term', 9, 1),
('taxonomy_term', 10, 1),
('taxonomy_term', 11, 1),
('taxonomy_term', 12, 1);
