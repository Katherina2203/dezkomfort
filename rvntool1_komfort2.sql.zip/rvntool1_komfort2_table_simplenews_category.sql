
-- --------------------------------------------------------

--
-- Структура таблицы `simplenews_category`
--

CREATE TABLE `simplenews_category` (
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT 'taxonomy_term_data.tid used as newsletter category.',
  `format` varchar(8) NOT NULL DEFAULT '' COMMENT 'Format of the newsletter email (plain, html).',
  `priority` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Email priority according to RFC 2156 and RFC 5231 (0 = none; 1 = highest; 2 = high; 3 = normal; 4 = low; 5 = lowest).',
  `receipt` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Boolean indicating request for email receipt confirmation according to RFC 2822.',
  `from_name` varchar(128) NOT NULL DEFAULT '' COMMENT 'Sender name for newsletter emails.',
  `email_subject` varchar(255) NOT NULL DEFAULT '' COMMENT 'Subject of newsletter email. May contain tokens.',
  `from_address` varchar(64) NOT NULL DEFAULT '' COMMENT 'Sender address for newsletter emails',
  `hyperlinks` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Flag indicating type of hyperlink conversion (1 = hyperlinks are in-line; 0 = hyperlinks are placed at email bottom).',
  `new_account` varchar(12) NOT NULL DEFAULT '' COMMENT 'How to treat subscription at account creation (none = None; on = Default on; off = Default off; silent = Invisible subscription).',
  `opt_inout` varchar(12) NOT NULL DEFAULT '' COMMENT 'How to treat subscription confirmation (hidden = Newsletter is hidden from the user; single = Single opt-in; double = Double opt-in).',
  `block` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'For this category a subscription block is available.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simplenews newsletter categories.';

--
-- Дамп данных таблицы `simplenews_category`
--

INSERT INTO `simplenews_category` (`tid`, `format`, `priority`, `receipt`, `from_name`, `email_subject`, `from_address`, `hyperlinks`, `new_account`, `opt_inout`, `block`) VALUES
(13, 'plain', 0, 0, 'Комфорт', '[[simplenews-category:name]] [node:title]', 'dezkomfort@mail.ua', 1, 'none', 'double', 1),
(14, 'plain', 3, 1, 'Комфорт-санитарная служба', '[[simplenews-category:name]] [node:title]', 'dezkomfort@mail.ua', 1, 'on', 'double', 1);
