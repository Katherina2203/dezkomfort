
-- --------------------------------------------------------

--
-- Структура таблицы `simplenews_mail_spool`
--

CREATE TABLE `simplenews_mail_spool` (
  `msid` int(10) UNSIGNED NOT NULL COMMENT 'The primary identifier for a mail spool record.',
  `mail` varchar(255) NOT NULL DEFAULT '' COMMENT 'The formatted email address of mail message recipient.',
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'The node.nid of this newsletter.',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT 'The simplenews_category.tid this newsletter belongs to.',
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The sent status of the email (0 = hold, 1 = pending, 2 = done).',
  `error` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether an error occured while sending the email.',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The time status was set or changed.',
  `data` longtext COMMENT 'A serialized array of name value pairs that are related to the email address.',
  `snid` int(11) NOT NULL DEFAULT '0' COMMENT 'Foreign key for subscriber table (simplenews_subscriptions.snid)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Spool for temporary storage of newsletter emails.';
