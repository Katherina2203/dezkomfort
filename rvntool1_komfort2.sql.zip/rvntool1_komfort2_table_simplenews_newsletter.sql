
-- --------------------------------------------------------

--
-- Структура таблицы `simplenews_newsletter`
--

CREATE TABLE `simplenews_newsletter` (
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'node that is used as newsletter.',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT 'The newsletter category simplenews_category.tid this newsletter belongs to.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'sent status of the newsletter issue (0 = not sent; 1 = pending; 2 = sent, 3 = send on publish).',
  `sent_subscriber_count` int(11) NOT NULL DEFAULT '0' COMMENT 'The count of subscribers to the newsletter when it was sent.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simplenews newsletter data.';
