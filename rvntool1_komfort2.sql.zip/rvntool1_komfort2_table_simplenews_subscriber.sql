
-- --------------------------------------------------------

--
-- Структура таблицы `simplenews_subscriber`
--

CREATE TABLE `simplenews_subscriber` (
  `snid` int(11) NOT NULL COMMENT 'Primary key: Unique subscriber ID.',
  `activated` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating the status of the subscription.',
  `mail` varchar(64) NOT NULL DEFAULT '' COMMENT 'The subscriber’s email address.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that has the same email address.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'Subscriber preferred language.',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp of when the user is (un)subscribed.',
  `changes` text COMMENT 'Contains the requested subscription changes',
  `created` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp of when the subscription record was added.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Subscribers to simplenews_category. Many-to-many relation...';

--
-- Дамп данных таблицы `simplenews_subscriber`
--

INSERT INTO `simplenews_subscriber` (`snid`, `activated`, `mail`, `uid`, `language`, `timestamp`, `changes`, `created`) VALUES
(1, 1, 'vovk.katya@gmail.com', 1, '', 0, 'a:0:{}', 1467294616),
(2, 1, 'ya.elijah2015@ya.ru', 49, '', 0, 'a:0:{}', 1492514620);
