
-- --------------------------------------------------------

--
-- Структура таблицы `simplenews_subscription`
--

CREATE TABLE `simplenews_subscription` (
  `snid` int(11) NOT NULL DEFAULT '0' COMMENT 'The simplenews_subscriber.snid who is subscribed.',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT 'The category (simplenews_category.tid) the subscriber is subscribed to.',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'A flag indicating whether the user is subscribed (1) or unsubscribed (0).',
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp of when the user is (un)subscribed.',
  `source` varchar(24) NOT NULL DEFAULT '' COMMENT 'The source via which the user is (un)subscription.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter subscription data. Which subscriber is...';

--
-- Дамп данных таблицы `simplenews_subscription`
--

INSERT INTO `simplenews_subscription` (`snid`, `tid`, `status`, `timestamp`, `source`) VALUES
(1, 14, 1, 1467294616, 'website'),
(2, 14, 1, 1492514620, 'website');
