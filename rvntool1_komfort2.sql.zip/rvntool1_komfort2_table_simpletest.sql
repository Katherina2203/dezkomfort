
-- --------------------------------------------------------

--
-- Структура таблицы `simpletest`
--

CREATE TABLE `simpletest` (
  `message_id` int(11) NOT NULL COMMENT 'Primary Key: Unique simpletest message ID.',
  `test_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Test ID, messages belonging to the same ID are reported together',
  `test_class` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the class that created this message.',
  `status` varchar(9) NOT NULL DEFAULT '' COMMENT 'Message status. Core understands pass, fail, exception.',
  `message` text NOT NULL COMMENT 'The message itself.',
  `message_group` varchar(255) NOT NULL DEFAULT '' COMMENT 'The message group this message belongs to. For example: warning, browser, user.',
  `function` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the assertion function or method that created this message.',
  `line` int(11) NOT NULL DEFAULT '0' COMMENT 'Line number on which the function is called.',
  `file` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the file where the function is called.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores simpletest messages';
