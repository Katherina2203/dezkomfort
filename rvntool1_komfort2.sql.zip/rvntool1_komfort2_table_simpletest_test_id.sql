
-- --------------------------------------------------------

--
-- Структура таблицы `simpletest_test_id`
--

CREATE TABLE `simpletest_test_id` (
  `test_id` int(11) NOT NULL COMMENT 'Primary Key: Unique simpletest ID used to group test results together. Each time a set of tests\n                            are run a new test ID is used.',
  `last_prefix` varchar(60) DEFAULT '' COMMENT 'The last database prefix used during testing.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores simpletest test IDs, used to auto-incrament the...';
