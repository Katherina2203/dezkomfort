
-- --------------------------------------------------------

--
-- Структура таблицы `stylizer`
--

CREATE TABLE `stylizer` (
  `sid` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT 'Unique ID for this style. Used to identify it programmatically.',
  `admin_title` varchar(255) DEFAULT NULL COMMENT 'Human readable title for this style.',
  `admin_description` longtext COMMENT 'Administrative description of this style.',
  `settings` longtext COMMENT 'A serialized array of settings specific to the style base that describes this plugin.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customized stylizer styles created by administrative users.';
