
-- --------------------------------------------------------

--
-- Структура таблицы `taxonomy_index`
--

CREATE TABLE `taxonomy_index` (
  `nid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The node.nid this record tracks.',
  `tid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The term ID.',
  `sticky` tinyint(4) DEFAULT '0' COMMENT 'Boolean indicating whether the node is sticky.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was created.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maintains denormalized information about node/term...';

--
-- Дамп данных таблицы `taxonomy_index`
--

INSERT INTO `taxonomy_index` (`nid`, `tid`, `sticky`, `created`) VALUES
(23, 12, 0, 1465817784),
(24, 12, 0, 1465817867),
(25, 12, 0, 1465817996),
(26, 12, 0, 1465818077),
(33, 9, 0, 1465818649),
(34, 7, 0, 1465818711),
(36, 8, 0, 1465818796),
(37, 8, 0, 1465818924),
(38, 9, 0, 1465818980),
(39, 9, 0, 1465819428),
(40, 9, 0, 1465819549),
(41, 7, 0, 1465819644),
(27, 12, 0, 1465818122),
(31, 7, 0, 1465818510),
(32, 9, 0, 1465818560),
(35, 8, 0, 1465818751),
(29, 7, 0, 1465818322),
(22, 11, 0, 1465817725),
(28, 12, 0, 1465818164),
(21, 12, 0, 1465817579),
(11, 6, 0, 1382430950);
