
-- --------------------------------------------------------

--
-- Структура таблицы `taxonomy_term_data`
--

CREATE TABLE `taxonomy_term_data` (
  `tid` int(10) UNSIGNED NOT NULL COMMENT 'Primary Key: Unique term ID.',
  `vid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The taxonomy_vocabulary.vid of the vocabulary to which the term is assigned.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The term name.',
  `description` longtext COMMENT 'A description of the term.',
  `format` varchar(255) DEFAULT NULL COMMENT 'The filter_format.format of the description.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The weight of this term in relation to other terms.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores term information.';

--
-- Дамп данных таблицы `taxonomy_term_data`
--

INSERT INTO `taxonomy_term_data` (`tid`, `vid`, `name`, `description`, `format`, `weight`) VALUES
(1, 1, 'Грибок', '', 'filtered_html', 0),
(2, 1, 'Грызуны', '', 'filtered_html', 0),
(3, 2, 'General discussion', '', NULL, 0),
(4, 2, 'Bootstrap Business', '', NULL, 1),
(5, 2, 'Bootstrap 3 Framework', '', NULL, 2),
(6, 1, 'Насекомые', '', 'filtered_html', 0),
(7, 4, 'Услуги для открытых территорий', '', 'filtered_html', 0),
(8, 4, 'Услуги для физических лиц', '', 'filtered_html', 0),
(9, 4, 'слуги для юридических лиц', '', 'filtered_html', 0),
(10, 3, 'Грызуны', '', 'full_html', 0),
(11, 3, 'Грибок', '', 'full_html', 0),
(12, 3, 'Насекомые', '', 'full_html', 0),
(13, 5, 'Комфорт newsletter', 'Комфорт newsletter categories.', NULL, 0),
(14, 5, 'Подписаться на новости', '', NULL, 0);
