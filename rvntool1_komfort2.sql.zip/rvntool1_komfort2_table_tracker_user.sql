
-- --------------------------------------------------------

--
-- Структура таблицы `tracker_user`
--

CREATE TABLE `tracker_user` (
  `nid` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The node.nid this record tracks.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid of the node author or commenter.',
  `published` tinyint(4) DEFAULT '0' COMMENT 'Boolean indicating whether the node is published.',
  `changed` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was most recently saved or commented on.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tracks when nodes were last changed or commented on, for...';

--
-- Дамп данных таблицы `tracker_user`
--

INSERT INTO `tracker_user` (`nid`, `uid`, `published`, `changed`) VALUES
(20, 0, 1, 1468828697),
(45, 1, 0, 1465977574),
(51, 1, 0, 1470297834),
(13, 1, 1, 1465809519),
(23, 1, 1, 1465817784),
(24, 1, 1, 1465817867),
(25, 1, 1, 1465817996),
(26, 1, 1, 1465818077),
(33, 1, 1, 1465818649),
(34, 1, 1, 1465818711),
(36, 1, 1, 1465818796),
(37, 1, 1, 1465818924),
(38, 1, 1, 1465818980),
(39, 1, 1, 1465819428),
(40, 1, 1, 1465819549),
(41, 1, 1, 1465819644),
(44, 1, 1, 1465821586),
(43, 1, 1, 1465821624),
(46, 1, 1, 1465892958),
(27, 1, 1, 1465997100),
(31, 1, 1, 1467293473),
(32, 1, 1, 1467293518),
(35, 1, 1, 1467293942),
(30, 1, 1, 1468396233),
(29, 1, 1, 1468396459),
(22, 1, 1, 1468409079),
(28, 1, 1, 1468409117),
(21, 1, 1, 1468409281),
(42, 1, 1, 1468568995),
(49, 1, 1, 1468828556),
(47, 1, 1, 1468828618),
(48, 1, 1, 1468828654),
(20, 1, 1, 1468828697),
(19, 1, 1, 1468828722),
(18, 1, 1, 1468828758),
(16, 1, 1, 1468828850),
(15, 1, 1, 1468828869),
(14, 1, 1, 1468828904),
(4, 1, 1, 1468828927),
(11, 1, 1, 1468828954),
(3, 1, 1, 1468828971),
(6, 1, 1, 1468829099),
(52, 1, 1, 1470300326),
(17, 1, 1, 1492515997);
