
-- --------------------------------------------------------

--
-- Структура таблицы `url_alias`
--

CREATE TABLE `url_alias` (
  `pid` int(10) UNSIGNED NOT NULL COMMENT 'A unique path alias identifier.',
  `source` varchar(255) NOT NULL DEFAULT '' COMMENT 'The Drupal path this alias is for; e.g. node/12.',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'The alias for this path; e.g. title-of-the-story.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The language this alias is for; if ’und’, the alias will be used for unknown languages. Each Drupal path can have an alias for each supported language.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='A list of URL aliases for Drupal paths; a user may visit...';

--
-- Дамп данных таблицы `url_alias`
--

INSERT INTO `url_alias` (`pid`, `source`, `alias`, `language`) VALUES
(1, 'taxonomy/term/1', 'tags/грибок', 'und'),
(2, 'taxonomy/term/2', 'tags/грызуны', 'und'),
(3, 'taxonomy/term/6', 'tags/насекомые', 'und'),
(4, 'taxonomy/term/7', 'услуги/услуги-для-открытых-территорий', 'und'),
(5, 'taxonomy/term/8', 'услуги/услуги-для-физических-лиц', 'und'),
(6, 'taxonomy/term/9', 'услуги/слуги-для-юридических-лиц', 'und'),
(7, 'taxonomy/term/10', 'справочник-вредителей/грызуны', 'und'),
(8, 'taxonomy/term/11', 'справочник-вредителей/грибок', 'und'),
(9, 'taxonomy/term/12', 'справочник-вредителей/насекомые', 'und'),
(10, 'node/14', 'news/что-мы-знаем-о-плесени', 'ru'),
(11, 'node/15', 'news/﻿преимущества-используемых-препаратов', 'ru'),
(12, 'node/16', 'news/обработка-сухой-туман', 'ru'),
(13, 'node/17', 'news/что-уничтожает-сухой-туман', 'ru'),
(14, 'node/18', 'news/клещи-в-харькове', 'ru'),
(15, 'node/19', 'news/профессиональные-услуги-дезинсекции', 'ru'),
(16, 'node/20', 'news/проблема-устранения-плесени', 'ru'),
(17, 'node/21', 'spravochnik/комары', 'ru'),
(18, 'node/22', 'spravochnik/плесень', 'ru'),
(19, 'node/23', 'spravochnik/тараканы', 'ru'),
(20, 'node/24', 'spravochnik/муравьи', 'ru'),
(21, 'node/25', 'spravochnik/клопы', 'ru'),
(22, 'node/26', 'spravochnik/клещи', 'ru'),
(23, 'node/27', 'spravochnik/блохи', 'ru'),
(24, 'node/28', 'spravochnik/моль', 'ru'),
(25, 'node/29', 'servises/уничтожение-комаров', 'ru'),
(26, 'node/30', 'услуги', 'ru'),
(27, 'node/31', 'servises/услуги-для-открытых-территорий', 'ru'),
(28, 'node/32', 'servises/услуги-для-юридических-лиц', 'ru'),
(29, 'node/33', 'servises/насекомые-в-кафе-и-ресторане', 'ru'),
(30, 'node/34', 'servises/обработка-участков-от-клещей', 'ru'),
(31, 'node/35', 'servises/услуги-для-физических-лиц', 'ru'),
(32, 'node/36', 'servises/уничтожение-тараканов', 'ru'),
(33, 'node/37', 'servises/уничтожение-клопов-в-харькове', 'ru'),
(34, 'node/38', 'servises/дезинфекция-мебели', 'ru'),
(35, 'node/39', 'servises/дезинфекция-воздушных-судов', 'ru'),
(36, 'node/40', 'servises/дезинфекция-в-стоматологических-кабинетах', 'ru'),
(37, 'node/41', 'servises/борьба-и-уничтожение-муравьев', 'ru'),
(38, 'node/42', 'стоимость-услуг', 'ru'),
(39, 'node/43', 'content/страница-не-найдена', 'ru'),
(40, 'node/44', 'content/нет-доступа', 'ru'),
(41, 'node/45', 'index', 'ru'),
(49, 'node/13', 'о-нас', 'und'),
(50, 'user/1', 'users/deziadmin', 'und'),
(51, 'blog/1', 'blogs/deziadmin', 'und'),
(52, 'user/28', 'users/vladimir', 'und'),
(53, 'blog/28', 'blogs/vladimir', 'und'),
(54, 'node/46', 'скидки-и-акции', 'ru'),
(55, 'node/47', 'reviews/муравьев-нет', 'ru'),
(56, 'node/48', 'reviews/рекомендую', 'ru'),
(57, 'node/49', 'reviews/отзывы', 'ru'),
(58, 'taxonomy/term/13', 'newsletter/комфорт-newsletter', 'und'),
(59, 'taxonomy/term/14', 'newsletter/подписаться-на-новости', 'und'),
(61, 'node/51', 'news-panel', 'ru'),
(62, 'node/52', 'комфорт', 'ru'),
(63, 'user/49', 'users/vipadmin', 'und'),
(64, 'blog/49', 'blogs/vipadmin', 'und');
