
-- --------------------------------------------------------

--
-- Структура таблицы `xmlsitemap_sitemap`
--

CREATE TABLE `xmlsitemap_sitemap` (
  `smid` varchar(64) NOT NULL COMMENT 'The sitemap ID (the hashed value of xmlsitemap.context.',
  `context` text NOT NULL COMMENT 'Serialized array with the sitemaps context',
  `updated` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `links` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `chunks` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `max_filesize` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `xmlsitemap_sitemap`
--

INSERT INTO `xmlsitemap_sitemap` (`smid`, `context`, `updated`, `links`, `chunks`, `max_filesize`) VALUES
('NXhscRe0440PFpI5dSznEVgmauL25KojD7u4e9aZwOM', 'a:0:{}', 1468828583, 8, 1, 1396);
